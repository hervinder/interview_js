# vanilla-javascript-ecommerce
Build an E-Commerce project using Vanilla javascript, content full, Netlify for hosting. 
